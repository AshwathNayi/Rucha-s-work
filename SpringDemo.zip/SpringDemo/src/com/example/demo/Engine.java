package com.example.demo;

public interface Engine {
   public void start();
}
