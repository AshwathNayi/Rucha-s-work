package com.example.demo;

public class Aeroplane implements Engine{

	@Override
	public void start() {
		// TODO Auto-generated method stub
		System.out.println("Aeroplane has started");
	}

}
