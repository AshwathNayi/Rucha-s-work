package com.example.demo;

public class Car implements Engine{

	@Override
	public void start() {
		// TODO Auto-generated method stub
		System.out.println("car has started");
	}

}
