package com.example.demo;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;


public class Main {

	public static void main(String[] args) {
//		// TODO Auto-generated method stub
        ApplicationContext ac=new ClassPathXmlApplicationContext("Beans.xml");
        //Engine en=ac.getBean("engine",Engine.class);
        Engine en=(Engine)ac.getBean("car");
        Engine en1=(Engine)ac.getBean("engine");
		en.start();
		en1.start();
	}

}
