package com.example.demo;

public class Bike implements Engine{

	@Override
	public void start() {
		// TODO Auto-generated method stub
		System.out.println("bike has started");
	}

}
