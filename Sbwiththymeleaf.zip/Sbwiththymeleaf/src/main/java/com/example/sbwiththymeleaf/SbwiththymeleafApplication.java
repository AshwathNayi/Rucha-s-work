package com.example.sbwiththymeleaf;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SbwiththymeleafApplication {

	public static void main(String[] args) {
		SpringApplication.run(SbwiththymeleafApplication.class, args);
	}

}
