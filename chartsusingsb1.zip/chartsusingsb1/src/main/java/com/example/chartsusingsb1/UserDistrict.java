package com.example.chartsusingsb1;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.*;

public interface UserDistrict extends JpaRepository<District, Long> {
	@Query(value="select distinct districtname,sum(schoolcount) As schoolcount from Districtschooldata group by districtname order by districtname",nativeQuery=true)
	List<Map<String,Object>> getchartdata();
	
	Optional<District> findById(Long Id);
	
	@Query(value="SELECT distinct districtschooldata.districtname,sum(districtschooldata.schoolcount) FILTER (WHERE districtschooldata.schooltype = 'government') AS government,sum(districtschooldata.schoolcount) FILTER (WHERE districtschooldata.schooltype = 'semigovernment') AS semigovernment,sum(districtschooldata.schoolcount) FILTER (WHERE districtschooldata.schooltype = 'pri') AS pri ,sum(districtschooldata.schoolcount) AS schoolcount from districtschooldata group by districtname order by districtname",nativeQuery=true)
	 List<Map<String,Object>> getchartdatanew();
}
