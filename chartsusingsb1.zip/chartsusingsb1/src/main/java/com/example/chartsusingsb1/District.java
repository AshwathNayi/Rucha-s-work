package com.example.chartsusingsb1;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "Districtschooldata")
public class District{

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="Id")
	private Long Id;
	@Column(name="districtname")
	private String name;
	@Column(name="schoolcount")
	private int schoolcount;
	@Column(name="schooltype")
	private String schooltype;
	public Long getId() {
		return Id;
	}
	public void setId(Long id) {
		Id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getSchoolcount() {
		return schoolcount;
	}
	public void setSchoolcount(int schoolcount) {
		this.schoolcount = schoolcount;
	}
	public String getSchooltype() {
		return schooltype;
	}
	public void setSchooltype(String schooltype) {
		this.schooltype = schooltype;
	}
	@Override
	public String toString() {
		return "District [Id=" + Id + ", name=" + name + ", schoolcount=" + schoolcount + ", schooltype=" + schooltype
				+ "]";
	}
	
	
}
