package com.example.chartsusingsb1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Chartsusingsb1Application {

	public static void main(String[] args) {
		SpringApplication.run(Chartsusingsb1Application.class, args);
	}

}
