package com.example.chartsusingsb1;


import java.util.Arrays;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.ResponseBody;


@Controller

public class UserController {

private final UserDistrict dst;
	
	@Autowired
	public UserController(UserDistrict dst)
	{
		this.dst = dst;
	}

	@GetMapping("/register")
	public String showForm(Model model)
	{
		District dst = new District();
		model.addAttribute("dst", dst);
		List<String> listschooltype=Arrays.asList("government","semigovernment","pri");
		model.addAttribute("listschooltype",listschooltype);
		System.out.println("dst"+dst);
		return "register";
	}
	@PostMapping("/newuser")
	public String showDetails(District d,BindingResult result,Model model)
	{
		if(result.hasErrors()) 
		{
			return "register";
		}
		dst.save(d);
		model.addAttribute("dsts",dst.findAll());
		return "NewUser";
	}
	@GetMapping("/getchartdata")
	@ResponseBody
	public List<Map<String,Object>> getchartdata()
	{
		List<Map<String,Object>> datadist = dst.getchartdata();
		return datadist;
	}
	@GetMapping("/getchartdatanew")
	@ResponseBody
	public List<Map<String,Object>> getchartdatanew()
	{
		List<Map<String,Object>> datadist = dst.getchartdatanew();
		return datadist;
	}
}