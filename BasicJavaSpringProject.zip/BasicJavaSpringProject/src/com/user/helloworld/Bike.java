package com.user.helloworld;

public class Bike implements Engine {
	public void run() 
	{
		System.out.println("bike is running");
	}

}
