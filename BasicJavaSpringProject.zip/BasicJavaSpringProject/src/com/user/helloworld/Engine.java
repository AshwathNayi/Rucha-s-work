package com.user.helloworld;

public interface Engine {
	public void run();

}
