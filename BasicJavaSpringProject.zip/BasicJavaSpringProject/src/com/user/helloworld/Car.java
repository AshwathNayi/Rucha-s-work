package com.user.helloworld;

public class Car implements Engine{
	public void run() 
	{
		System.out.println("car is running");
	}

}
