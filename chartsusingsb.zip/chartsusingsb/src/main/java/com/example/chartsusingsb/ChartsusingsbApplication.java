package com.example.chartsusingsb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ChartsusingsbApplication {

	public static void main(String[] args) {
		SpringApplication.run(ChartsusingsbApplication.class, args);
	}

}
