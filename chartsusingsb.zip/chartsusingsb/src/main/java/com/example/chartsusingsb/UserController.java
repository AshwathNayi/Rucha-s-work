package com.example.chartsusingsb;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class UserController 
{
	private final UserDistrict usrdist;
	
	@Autowired
	public UserController(UserDistrict usrdist)
	{
		this.usrdist = usrdist;
	}
    @GetMapping("/registration")
    public String showForm(Model model)
    {
    	District duser=new District();
    	model.addAttribute("duser",duser);
    	return "registration";
    }
//    @GetMapping("/getValue")
//    public String EnterValue(Model model)
//    {
//    	User user=new User();
//    	model.addAttribute("user",user);
//    	return "charts";
//    }
}
