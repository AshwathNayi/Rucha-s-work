package com.example.chartsusingsb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ChartsusingsbApplicationTests {

	@Test
	void contextLoads() {
	}

}
