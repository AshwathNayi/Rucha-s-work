import java.net.URL;
import sun.net.www.protocol.https.*;

import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import org.json.simple.JSONObject
public class Test {
	
	
	public static void main(String args[]) throws IOException {

		  final String USER_AGENT = "Mozilla/5.0";

 //final String GET_URL = "https://localhost:9090/SpringMVCExample";

 //final String POST_URL = "https://localhost:9090/SpringMVCExample/home";

	final String POST_PARAMS = "userName=Pankaj";
		
		String ResourceUrl =
				  "http://umd.nic.in/server/rest/services/Gati_Shakti/GatiShakti_pwd/MapServer/0/query?where=1=1&outFields=*&f=geojson";
				 // URL url = new URL(null, ResourceUrl, new sun.net);
		
				 // URL url = new URL("https://redmine.xxx.cz/time_entries.xml");
			       //  HttpURLConnection httpCon = (HttpURLConnection) url.openConnection(); //this line throws exception
			         
			         
			         
			         
			         URL obj = new URL(ResourceUrl);
			 		HttpURLConnection con = (HttpURLConnection) obj.openConnection();
			 		con.setRequestMethod("GET");
			 		//con.setRequestProperty("User-Agent", USER_AGENT);
			 		int responseCode = con.getResponseCode();
			 		System.out.println("GET Response Code :: " + responseCode);
			 		if (responseCode == HttpURLConnection.HTTP_OK) { // success
			 			BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
			 			String inputLine;
			 			StringBuffer response = new StringBuffer();

			 			while ((inputLine = in.readLine()) != null) {
			 				response.append(inputLine);
			 				
			 			}
			 			in.close();

			 			// print result
			 			System.out.println(response.toString());
			 			
			 		} else {
			 			System.out.println("GET request did not work.");
			 		}
	}

}
